package rru.csit.firstprogram;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
	EditText editText1,editText2;
	Button button1,button2,button3,button4;
	TextView textview1;
	float result;
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1=(EditText)findViewById(R.id.editText1);
        editText2=(EditText)findViewById(R.id.editText2);
        button1=(Button)findViewById(R.id.button1);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        button4=(Button)findViewById(R.id.button4);
        textview1=(TextView)findViewById(R.id.textView2);
        
        button1.setOnClickListener(new OnClickListener() {
        				
			public void onClick(View v) {
				// TODO Auto-generated method stub
			result=Float.parseFloat(editText1.getText().toString())+
				   Float.parseFloat(editText2.getText().toString());
			textview1.setText("result is:"+result);                   
			}
		});
        button1.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			result=Float.parseFloat(editText1.getText().toString())-
				   Float.parseFloat(editText2.getText().toString());
			textview1.setText("result is:"+result);                   
			}
		});
        button1.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			result=Float.parseFloat(editText1.getText().toString())*
				   Float.parseFloat(editText2.getText().toString());
			textview1.setText("result is:"+result);                   
			}
		});
        button1.setOnClickListener(new OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
			result=Float.parseFloat(editText1.getText().toString())/
				   Float.parseFloat(editText2.getText().toString());
			textview1.setText("result is:"+result);                   
			}
		});
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
        
    }
}
